# NetShield Ultimate 🛡️🧬⚔️

一款功能强大的 Android VPN 安全应用，融合 AI 智能分析、多跳 VPN、Tor 桥接、P2P 加速等多种高级功能。

**新增：自动进化系统 + 战斗经验系统！**

## ✨ 功能特性

### 🔒 安全防护
- **AI 威胁检测**: TensorFlow Lite 融合模型实时分析网络流量
- **硬件防护**: 监控摄像头、麦克风、USB、屏幕访问
- **防火墙**: 智能流量过滤和阻断

### 🌐 VPN 模式（5种）
| 模式 | 描述 |
|------|------|
| **标准** | 基础 VPN + AI 防火墙 |
| **安全核心** | 双跳加密 + 硬件防护 |
| **Tor** | VPN + Tor 桥接，三重匿名 |
| **P2P加速** | 优化路由 + 安全下载 |
| **隐身** | 深度混淆 + 反审查 |

### 🧬 进化系统 (Evolution System)
NetShield Ultimate 现在拥有**自动进化能力**！

#### 1. 技术侦察 (TechScout)
- 全网扫描安全资讯、学术论文、开源项目
- 监控暗网威胁情报
- 自动发现新的安全技术

#### 2. 自动学习 (AutoLearner)
- AI 自动分析并学习新技术
- 代码自动生成与合成
- 沙盒测试验证

#### 3. 能力部署 (CapabilityIntegrator)
- 热替换更新（无需重启）
- 金丝雀部署策略
- 自动回滚机制

#### 4. 战斗经验系统 (Combat System)
- **实时战斗学习**: 在真实攻击中获取经验
- **技能树系统**: RPG风格的技能升级
  - 钢铁堡垒系（防御专精）
  - 复仇猎手系（反击专精）
  - 无限适应系（进化专精）
- **对策锻造**: 紧急情况下快速生成防御代码
- **战斗记忆**: 记录攻击者档案，预测下一步行动

### ⚡ 性能优化
- **2ms 超低延迟**: 极致优化的响应时间
- **NPU 加速**: vivo Y300 等设备的神经网络加速
- **多线程处理**: 8 线程并行处理

## 🛠️ 技术栈

- **语言**: Kotlin
- **UI**: Jetpack Compose + Navigation
- **依赖注入**: Hilt
- **网络**: OkHttp, WireGuard, Tor
- **AI**: TensorFlow Lite
- **数据库**: Room
- **协程**: Kotlin Coroutines

## 📁 项目结构

```
NetShield-Ultimate/
├── app/src/main/java/com/netshield/ultimate/
│   ├── core/                    # 核心引擎
│   │   ├── UltimateEngine.kt
│   │   ├── AIAnalyzer.kt
│   │   ├── ThreatOrchestrator.kt
│   │   └── DefenseCoordinator.kt
│   ├── service/                 # VPN 服务
│   │   └── UltimateVpnService.kt
│   ├── vpn/                     # VPN 模块
│   │   ├── multihop/            # 多跳 VPN
│   │   ├── p2p/                 # P2P 加速
│   │   └── split/               # 分流设置
│   ├── defense/                 # 安全防护
│   │   └── firewall/
│   ├── ui/                      # 用户界面
│   │   ├── screens/
│   │   └── theme/
│   │
│   ├── 🆕 evolution/            # 【新增】进化系统
│   │   ├── discovery/           # 技术侦察
│   │   │   ├── TechScout.kt
│   │   │   └── NetworkScanner.kt
│   │   ├── learning/            # 自动学习
│   │   │   └── AutoLearner.kt
│   │   ├── synthesis/           # 代码合成
│   │   │   └── CodeSynthesizer.kt
│   │   ├── deployment/          # 能力部署
│   │   │   └── CapabilityIntegrator.kt
│   │   └── ui/                  # 进化系统UI
│   │       ├── EvolutionDashboard.kt
│   │       └── EvolutionViewModel.kt
│   │
│   ├── 🆕 warroom/              # 【新增】战斗系统
│   │   ├── combat/              # 战斗引擎
│   │   │   ├── CombatExperienceEngine.kt
│   │   │   └── CountermeasureForge.kt
│   │   ├── experience/          # 经验系统
│   │   │   ├── BattleMemory.kt
│   │   │   └── SkillTree.kt
│   │   └── ui/                  # 战斗系统UI
│   │       ├── CombatDashboard.kt
│   │       └── CombatViewModel.kt
│   │
│   ├── MainActivity.kt
│   └── NetShieldApp.kt
│
└── app/src/main/res/            # 资源文件
```

## 🚀 快速开始

### 环境要求

| 项目 | 版本 |
|------|------|
| Android Studio | Hedgehog (2023.1.1) 或更高 |
| JDK | 17 |
| Android SDK | 34 |
| Gradle | 8.2 |
| Kotlin | 1.9.22 |

### 构建步骤

#### 方法 1: Android Studio（推荐）

1. **解压项目**
   ```bash
   tar -xzf NetShield-Ultimate.zip
   ```

2. **打开项目**
   - 启动 Android Studio
   - `File > Open` → 选择 `NetShield-Ultimate` 文件夹

3. **等待 Gradle 同步**
   - 首次打开会自动下载依赖
   - 等待同步完成（可能需要几分钟）

4. **配置 SDK 路径**
   - 编辑 `local.properties` 文件
   - 修改 `sdk.dir` 为你本地的 Android SDK 路径
   - Windows: `sdk.dir=C\:\\Users\\YourName\\AppData\\Local\\Android\\Sdk`
   - macOS: `sdk.dir=/Users/yourname/Library/Android/sdk`
   - Linux: `sdk.dir=/home/yourname/Android/Sdk`

5. **构建 APK**
   - `Build > Generate Signed Bundle / APK...`
   - 选择 `APK`
   - 创建新的签名密钥或选择现有密钥
   - 选择 `release` 构建类型
   - 点击 `Finish`

#### 方法 2: 命令行

```bash
# 1. 解压项目
tar -xzf NetShield-Ultimate.zip
cd NetShield-Ultimate

# 2. 配置 SDK 路径（根据你的系统修改）
echo "sdk.dir=/Users/yourname/Library/Android/sdk" > local.properties

# 3. 构建 Debug APK
./gradlew assembleDebug

# 4. 构建 Release APK（需要配置签名）
./gradlew assembleRelease
```

### 安装 APK

```bash
# 安装 Debug 版本
adb install app/build/outputs/apk/debug/app-debug.apk

# 安装 Release 版本
adb install app/build/outputs/apk/release/app-release.apk
```

## 🎮 使用指南

### 进化系统
1. 打开应用，在主界面点击 **"技术进化"** 按钮
2. 进入进化仪表板，查看：
   - 系统进化状态
   - 网络扫描结果
   - 新发现的技术
   - 学习中的任务
   - 待部署的能力

### 战斗模式
1. 在主界面点击 **"战斗模式"** 按钮
2. 进入战斗仪表板，查看：
   - 当前等级和经验
   - 活跃的战斗
   - 技能树
   - 锻造的武器

### 技能树
- **钢铁堡垒系**: 提升防御能力
- **复仇猎手系**: 提升反击能力
- **无限适应系**: 提升进化速度

## 📋 配置说明

### 最低配置
- Android 10 (API 29)
- ARM64 或 ARMv7 处理器
- 100MB 可用存储空间

### 推荐配置
- Android 13+ (API 33+)
- ARM64 处理器
- 4GB RAM
- NPU 加速支持

## 🔧 常见问题

### Q: Gradle 同步失败？
**A:** 
1. 检查网络连接
2. 尝试 `File > Invalidate Caches / Restart`
3. 确保 JDK 17 已正确配置

### Q: 找不到 Android SDK？
**A:** 编辑 `local.properties` 文件，设置正确的 SDK 路径

### Q: 编译报错关于 TensorFlow Lite？
**A:** 这是正常情况，需要添加 TFLite 模型文件到 `assets/` 目录

## 📄 许可证

Copyright © 2024 NetShield. All rights reserved.

## ⚠️ 免责声明

本应用仅供学习和研究使用。使用 VPN 服务请遵守当地法律法规。

---

**Made with ❤️ by NetShield Team**

🛡️ 安全防护 | 🧬 自动进化 | ⚔️ 战斗升级
