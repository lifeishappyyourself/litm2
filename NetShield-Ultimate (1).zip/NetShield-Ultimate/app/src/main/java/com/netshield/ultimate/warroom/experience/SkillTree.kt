package com.netshield.ultimate.warroom.experience

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SkillTree @Inject constructor() {
    
    private val _unlockedNodes = MutableStateFlow<Set<SkillNode>>(emptySet())
    val unlockedNodes: StateFlow<Set<SkillNode>> = _unlockedNodes
    
    private val _playerStats = MutableStateFlow(PlayerStats())
    val playerStats: StateFlow<PlayerStats> = _playerStats
    
    // 技能树定义
    val skillTree = SkillTreeDefinition(
        branches = listOf(
            SkillBranch(
                name = "Iron Fortress",
                description = "终极防御大师",
                nodes = listOf(
                    SkillNode(
                        id = "basic_detection",
                        name = "基础侦测",
                        description = "发现明显攻击",
                        maxLevel = 5,
                        effects = listOf(Effect.DetectionRange(10))
                    ),
                    SkillNode(
                        id = "advanced_heuristics",
                        name = "高级启发式",
                        description = "发现未知威胁",
                        maxLevel = 5,
                        unlockRequirement = UnlockRequirement.Node("basic_detection", 3),
                        effects = listOf(Effect.UnknownThreatDetection(20))
                    ),
                    SkillNode(
                        id = "predictive_defense",
                        name = "预测防御",
                        description = "在攻击发生前阻断",
                        maxLevel = 3,
                        effects = listOf(Effect.PredictionAccuracy(30))
                    )
                )
            ),
            SkillBranch(
                name = "Vengeful Hunter",
                description = "以攻为守，追踪反击",
                nodes = listOf(
                    SkillNode(
                        id = "attribution_basic",
                        name = "基础归因",
                        description = "追踪攻击来源",
                        maxLevel = 5,
                        effects = listOf(Effect.AttributionAccuracy(15))
                    ),
                    SkillNode(
                        id = "counter_attack",
                        name = "合法反击",
                        description = "干扰攻击者C2",
                        maxLevel = 5,
                        unlockRequirement = UnlockRequirement.Node("attribution_basic", 3),
                        effects = listOf(Effect.CounterAttackSuccess(25))
                    )
                )
            ),
            SkillBranch(
                name = "Adaptive Evolution",
                description = "在战斗中快速进化",
                nodes = listOf(
                    SkillNode(
                        id = "rapid_learning",
                        name = "快速学习",
                        description = "战斗中经验获取+50%",
                        maxLevel = 5,
                        effects = listOf(Effect.ExperienceGain(50))
                    ),
                    SkillNode(
                        id = "stress_evolution",
                        name = "压力进化",
                        description = "危机时紧急进化新能力",
                        maxLevel = 3,
                        effects = listOf(Effect.EmergencyEvolutionSpeed(200))
                    )
                )
            )
        )
    )
    
    fun unlockNode(nodeId: String): Boolean {
        val node = findNode(nodeId) ?: return false
        if (!canUnlock(node)) return false
        
        val current = _unlockedNodes.value.toMutableSet()
        current.add(node.copy(currentLevel = 1))
        _unlockedNodes.value = current
        
        return true
    }
    
    fun upgradeNode(nodeId: String): Boolean {
        val current = _unlockedNodes.value.find { it.id == nodeId } ?: return false
        val definition = findNode(nodeId) ?: return false
        if (current.currentLevel >= definition.maxLevel) return false
        
        val updated = current.copy(currentLevel = current.currentLevel + 1)
        _unlockedNodes.value = _unlockedNodes.value.map {
            if (it.id == nodeId) updated else it
        }.toSet()
        
        return true
    }
    
    fun addExperience(category: TechniqueCategory, amount: Long): Boolean {
        val current = _playerStats.value
        val newTotal = current.experienceByCategory[category]?.plus(amount) ?: amount
        
        _playerStats.value = current.copy(
            experienceByCategory = current.experienceByCategory + (category to newTotal),
            totalExperience = current.totalExperience + amount
        )
        
        return checkForUnlockableNodes()
    }
    
    private fun checkForUnlockableNodes(): Boolean {
        var leveledUp = false
        skillTree.allNodes.forEach { node ->
            if (node.id !in _unlockedNodes.value.map { it.id } && canUnlock(node)) {
                if (unlockNode(node.id)) leveledUp = true
            }
        }
        return leveledUp
    }
    
    private fun canUnlock(node: SkillNode): Boolean {
        return node.unlockRequirement?.let { req ->
            when (req) {
                is UnlockRequirement.Node -> {
                    val prerequisite = _unlockedNodes.value.find { it.id == req.nodeId }
                    prerequisite != null && prerequisite.currentLevel >= req.level
                }
                else -> true
            }
        } ?: true
    }
    
    private fun findNode(nodeId: String): SkillNode? {
        return skillTree.allNodes.find { it.id == nodeId }
    }
    
    data class PlayerStats(
        val totalExperience: Long = 0,
        val level: Int = 1,
        val experienceByCategory: Map<TechniqueCategory, Long> = emptyMap(),
        val title: String = "新兵",
        val specialization: CombatSpecialization = CombatSpecialization.NONE
    )
    
    enum class CombatSpecialization {
        NONE, DEFENSE_MASTER, COUNTER_ATTACKER, STEALTH_WARRIOR, ADAPTIVE_HUNTER
    }
    
    enum class TechniqueCategory {
        EXPLOIT_DEVELOPMENT, PERSISTENCE, EVASION,
        C2_COMMUNICATION, LATERAL_MOVEMENT, EXFILTRATION
    }
    
    data class SkillNode(
        val id: String,
        val name: String,
        val description: String,
        val maxLevel: Int,
        val currentLevel: Int = 0,
        val unlockRequirement: UnlockRequirement? = null,
        val effects: List<Effect>
    )
    
    sealed class UnlockRequirement {
        data class Node(val nodeId: String, val level: Int) : UnlockRequirement()
        data class Experience(val category: TechniqueCategory, val amount: Long) : UnlockRequirement()
        data class BattlesWon(val count: Int) : UnlockRequirement()
    }
    
    sealed class Effect {
        data class DetectionRange(val bonus: Int) : Effect()
        data class UnknownThreatDetection(val bonus: Int) : Effect()
        data class PredictionAccuracy(val bonus: Int) : Effect()
        data class AttributionAccuracy(val bonus: Int) : Effect()
        data class CounterAttackSuccess(val bonus: Int) : Effect()
        data class ExperienceGain(val bonus: Int) : Effect()
        data class EmergencyEvolutionSpeed(val bonus: Int) : Effect()
    }
    
    data class SkillBranch(
        val name: String,
        val description: String,
        val nodes: List<SkillNode>
    )
    
    data class SkillTreeDefinition(
        val branches: List<SkillBranch>
    ) {
        val allNodes: List<SkillNode> get() = branches.flatMap { it.nodes }
    }
}
