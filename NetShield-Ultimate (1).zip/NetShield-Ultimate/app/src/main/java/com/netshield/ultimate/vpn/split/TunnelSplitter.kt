package com.netshield.ultimate.vpn.split

import android.net.VpnService
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TunnelSplitter @Inject constructor() {
    
    fun applySplitTunneling(builder: VpnService.Builder, mode: VpnMode) {
        // 应用分流规则
    }
    
    enum class VpnMode {
        STANDARD, SECURE_CORE, TOR, P2P, STEALTH
    }
}
