package com.netshield.ultimate

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.netshield.ultimate.evolution.ui.EvolutionDashboard
import com.netshield.ultimate.ui.screens.UltimateDashboard
import com.netshield.ultimate.ui.theme.NetShieldTheme
import com.netshield.ultimate.warroom.ui.CombatDashboard
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        setContent {
            NetShieldTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    NetShieldApp()
                }
            }
        }
    }
    
    private fun startVpnService(mode: String) {
        val intent = Intent(this, service.UltimateVpnService::class.java).apply {
            action = when (mode) {
                "standard" -> service.UltimateVpnService.ACTION_START_STANDARD
                "secure_core" -> service.UltimateVpnService.ACTION_START_SECURE_CORE
                "tor" -> service.UltimateVpnService.ACTION_START_TOR
                "p2p" -> service.UltimateVpnService.ACTION_START_P2P
                "stealth" -> service.UltimateVpnService.ACTION_START_STEALTH
                else -> service.UltimateVpnService.ACTION_START_STANDARD
            }
        }
        startService(intent)
    }
    
    private fun stopVpnService() {
        val intent = Intent(this, service.UltimateVpnService::class.java).apply {
            action = service.UltimateVpnService.ACTION_STOP
        }
        startService(intent)
    }
}

@Composable
fun NetShieldApp() {
    val navController = rememberNavController()
    
    NavHost(navController = navController, startDestination = "main") {
        composable("main") {
            UltimateDashboard(
                onNavigateToEvolution = { navController.navigate("evolution") },
                onNavigateToCombat = { navController.navigate("combat") }
            )
        }
        composable("evolution") {
            EvolutionDashboard()
        }
        composable("combat") {
            CombatDashboard()
        }
    }
}
