package com.netshield.ultimate.vpn.multihop

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SecureCore @Inject constructor() {
    
    fun connectEntryNode(node: EntryNode) {
        // 连接入口节点
    }
    
    fun connectExitNode(node: ExitNode) {
        // 连接出口节点
    }
    
    fun encryptInner(data: ByteArray): ByteArray {
        return data
    }
    
    fun encryptOuter(data: ByteArray): ByteArray {
        return data
    }
    
    data class EntryNode(val host: String, val port: Int)
    data class ExitNode(val host: String, val port: Int)
}
