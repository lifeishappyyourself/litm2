package com.netshield.ultimate.evolution.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.netshield.ultimate.evolution.discovery.TechScout
import com.netshield.ultimate.evolution.learning.AutoLearner
import com.netshield.ultimate.evolution.deployment.CapabilityIntegrator

@Composable
fun EvolutionDashboard(viewModel: EvolutionViewModel = hiltViewModel()) {
    val techDiscoveries by viewModel.techDiscoveries.collectAsState()
    val learningTasks by viewModel.learningTasks.collectAsState()
    val integrationQueue by viewModel.integrationQueue.collectAsState()
    val networkScan by viewModel.networkScan.collectAsState()
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0F))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 进化状态概览
        item {
            EvolutionStatusCard(
                isActive = true,
                totalCapabilities = 47,
                evolvedCapabilities = 12,
                pendingEvolutions = learningTasks.count { it.status == AutoLearner.TaskStatus.ACTIVE }
            )
        }
        
        // 网络扫描状态
        item {
            NetworkScanCard(
                isScanning = networkScan.isScanning,
                lastScan = networkScan.lastScanTime,
                threatsFound = networkScan.threatsDiscovered,
                newTechFound = networkScan.newTechniquesFound
            )
        }
        
        // 新发现技术
        if (techDiscoveries.isNotEmpty()) {
            item {
                Text(
                    text = "新发现技术 (${techDiscoveries.size})",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            
            items(techDiscoveries.take(3)) { tech ->
                TechDiscoveryCard(tech = tech, onLearn = { viewModel.startLearning(tech) })
            }
        }
        
        // 学习中的任务
        if (learningTasks.isNotEmpty()) {
            item {
                Text(
                    text = "进化中 (${learningTasks.size})",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(top = 16.dp)
                )
            }
            
            items(learningTasks) { task ->
                LearningTaskCard(task = task)
            }
        }
        
        // 待部署集成
        if (integrationQueue.isNotEmpty()) {
            item {
                Text(
                    text = "待部署 (${integrationQueue.size})",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(top = 16.dp)
                )
            }
            
            items(integrationQueue) { task ->
                IntegrationTaskCard(task = task, onDeploy = { viewModel.deployIntegration(task) })
            }
        }
    }
}

@Composable
fun EvolutionStatusCard(
    isActive: Boolean,
    totalCapabilities: Int,
    evolvedCapabilities: Int,
    pendingEvolutions: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) Color(0xFF4CAF50).copy(alpha = 0.15f) 
                else Color(0xFF1A1A2E)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(60.dp),
                contentAlignment = Alignment.Center
            ) {
                if (isActive) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(48.dp),
                        color = Color(0xFF4CAF50)
                    )
                }
                Icon(
                    imageVector = Icons.Rounded.Biotech,
                    contentDescription = null,
                    tint = if (isActive) Color(0xFF4CAF50) else Color.Gray,
                    modifier = Modifier.size(32.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isActive) "系统正在进化" else "进化系统待机",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isActive) Color(0xFF4CAF50) else Color.White
                )
                
                Text(
                    text = "$evolvedCapabilities / $totalCapabilities 能力已进化" +
                           if (pendingEvolutions > 0) " • $pendingEvolutions 进行中" else "",
                    fontSize = 13.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

@Composable
fun NetworkScanCard(
    isScanning: Boolean,
    lastScan: Long,
    threatsFound: Int,
    newTechFound: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "全网技术侦察",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
                
                if (isScanning) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = Color(0xFF2196F3)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("扫描中...", fontSize = 12.sp, color = Color(0xFF2196F3))
                    }
                } else {
                    Text(
                        text = "上次: ${formatTimeAgo(lastScan)}",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }
            
            if (!isScanning && (threatsFound > 0 || newTechFound > 0)) {
                Spacer(modifier = Modifier.height(12.dp))
                
                Row {
                    if (threatsFound > 0) {
                        Surface(
                            color = Color(0xFFF44336).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "⚠ $threatsFound 新威胁",
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                color = Color(0xFFF44336),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                    
                    if (newTechFound > 0) {
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        Surface(
                            color = Color(0xFF2196F3).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "✦ $newTechFound 新技术",
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                color = Color(0xFF2196F3),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TechDiscoveryCard(tech: TechScout.DiscoveredTech, onLearn: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(
                        color = categoryColor(tech.category).copy(alpha = 0.2f),
                        shape = RoundedCornerShape(10.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = categoryIcon(tech.category),
                    contentDescription = null,
                    tint = categoryColor(tech.category),
                    modifier = Modifier.size(20.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = tech.name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
                Text(
                    text = "${tech.category.name} • 置信度: ${(tech.confidence * 100).toInt()}%",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }
            
            Button(
                onClick = onLearn,
                modifier = Modifier.height(32.dp)
            ) {
                Text("学习", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun LearningTaskCard(task: AutoLearner.LearningTask) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = task.tech.name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
                Text(
                    text = task.stage.name,
                    fontSize = 11.sp,
                    color = when (task.status) {
                        AutoLearner.TaskStatus.ACTIVE -> Color(0xFF4CAF50)
                        AutoLearner.TaskStatus.FAILED -> Color(0xFFF44336)
                        AutoLearner.TaskStatus.COMPLETED -> Color(0xFF2196F3)
                        else -> Color.Gray
                    }
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            LinearProgressIndicator(
                progress = { task.progress },
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF4CAF50),
                trackColor = Color(0xFF333344)
            )
        }
    }
}

@Composable
fun IntegrationTaskCard(
    task: CapabilityIntegrator.IntegrationTask,
    onDeploy: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.sourceTask.tech.name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
                Text(
                    text = "${task.integrationType.name} → ${task.targetModule}",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }
            
            if (task.stage == CapabilityIntegrator.IntegrationStage.QUEUED) {
                Button(onClick = onDeploy, modifier = Modifier.height(32.dp)) {
                    Text("部署", fontSize = 12.sp)
                }
            } else {
                Text(
                    text = task.stage.name,
                    fontSize = 11.sp,
                    color = Color(0xFF2196F3)
                )
            }
        }
    }
}

// Helper functions
private fun formatTimeAgo(timestamp: Long): String {
    val diff = System.currentTimeMillis() - timestamp
    return when {
        diff < 60000 -> "刚刚"
        diff < 3600000 -> "${diff / 60000}分钟前"
        diff < 86400000 -> "${diff / 3600000}小时前"
        else -> "${diff / 86400000}天前"
    }
}

private fun categoryColor(category: TechScout.TechCategory): Color {
    return when (category) {
        TechScout.TechCategory.ANTIVIRUS_HEURISTIC,
        TechScout.TechCategory.ANTIVIRUS_BEHAVIOR -> Color(0xFFF44336)
        TechScout.TechCategory.VPN_PROTOCOL,
        TechScout.TechCategory.VPN_OBFUSCATION -> Color(0xFF4CAF50)
        TechScout.TechCategory.FIREWALL_DEEP_INSPECTION,
        TechScout.TechCategory.FIREWALL_AI_DETECTION -> Color(0xFFFF9800)
        TechScout.TechCategory.CRYPTO_ALGORITHM -> Color(0xFF9C27B0)
        else -> Color(0xFF2196F3)
    }
}

private fun categoryIcon(category: TechScout.TechCategory): androidx.compose.ui.graphics.vector.ImageVector {
    return when (category) {
        TechScout.TechCategory.ANTIVIRUS_HEURISTIC,
        TechScout.TechCategory.ANTIVIRUS_BEHAVIOR -> Icons.Rounded.Security
        TechScout.TechCategory.VPN_PROTOCOL,
        TechScout.TechCategory.VPN_OBFUSCATION -> Icons.Rounded.VpnKey
        TechScout.TechCategory.FIREWALL_DEEP_INSPECTION,
        TechScout.TechCategory.FIREWALL_AI_DETECTION -> Icons.Rounded.Shield
        TechScout.TechCategory.CRYPTO_ALGORITHM -> Icons.Rounded.Lock
        else -> Icons.Rounded.Code
    }
}
