package com.netshield.ultimate

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class NetShieldApp : Application() {
    
    override fun onCreate() {
        super.onCreate()
        // 初始化应用
    }
}
