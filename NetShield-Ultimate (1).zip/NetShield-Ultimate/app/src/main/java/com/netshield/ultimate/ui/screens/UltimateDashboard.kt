package com.netshield.ultimate.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun UltimateDashboard(
    viewModel: UltimateViewModel = hiltViewModel(),
    onNavigateToEvolution: () -> Unit = {},
    onNavigateToCombat: () -> Unit = {}
) {
    val state by viewModel.state.collectAsState()
    
    Scaffold(
        topBar = { UltimateTopBar(state) },
        bottomBar = { UltimateBottomBar(state.selectedTab) { viewModel.selectTab(it) } },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 融合状态卡片：VPN+防火墙+硬件防护
            item {
                FusionStatusCard(
                    vpnState = state.vpnState,
                    threatLevel = state.threatLevel,
                    hardwareProtected = state.hardwareShieldsActive,
                    onConnect = { viewModel.connect(it) },
                    onDisconnect = { viewModel.disconnect() }
                )
            }
            
            // 实时威胁地图（融合网络+P2P+硬件威胁）
            item {
                ThreatMapCard(
                    networkThreats = state.networkThreats,
                    p2pThreats = state.p2pThreats,
                    hardwareAlerts = state.hardwareAlerts
                )
            }
            
            // 速度仪表盘（VPN+P2P融合统计）
            item {
                SpeedDashboard(
                    vpnSpeed = state.vpnSpeed,
                    p2pSpeed = state.p2pSpeed,
                    optimizationLevel = state.aiOptimizationLevel
                )
            }
            
            // 模式选择器（5种融合模式）
            item {
                ModeSelector(
                    currentMode = state.currentMode,
                    modes = listOf(
                        ModeConfig(
                            id = VpnMode.STANDARD,
                            name = "标准",
                            desc = "AI防火墙+基础VPN",
                            icon = Icons.Rounded.Shield,
                            color = Color(0xFF2196F3)
                        ),
                        ModeConfig(
                            id = VpnMode.SECURE_CORE,
                            name = "安全核心",
                            desc = "双跳加密+硬件防护",
                            icon = Icons.Rounded.Security,
                            color = Color(0xFF4CAF50)
                        ),
                        ModeConfig(
                            id = VpnMode.TOR,
                            name = "Tor",
                            desc = "三重匿名+洋葱访问",
                            icon = Icons.Rounded.VisibilityOff,
                            color = Color(0xFF9C27B0)
                        ),
                        ModeConfig(
                            id = VpnMode.P2P,
                            name = "P2P加速",
                            desc = "优化路由+安全下载",
                            icon = Icons.Rounded.Speed,
                            color = Color(0xFFFF9800)
                        ),
                        ModeConfig(
                            id = VpnMode.STEALTH,
                            name = "隐身",
                            desc = "深度混淆+反审查",
                            icon = Icons.Rounded.Lock,
                            color = Color.Gray
                        )
                    ),
                    onSelect = { viewModel.setMode(it) }
                )
            }
            
            // 快速操作网格
            item {
                QuickActionsGrid(
                    actions = listOf(
                        QuickAction("全盘扫描", Icons.Rounded.Search, "扫描") {
                            viewModel.startFullScan()
                        },
                        QuickAction("DNS更换", Icons.Rounded.Dns, "DNS") {
                            viewModel.showDNSSelector()
                        },
                        QuickAction("分流设置", Icons.Rounded.Menu, "分流") {
                            viewModel.showSplitTunnelConfig()
                        },
                        QuickAction("威胁日志", Icons.Rounded.History, "日志") {
                            viewModel.showThreatLogs()
                        }
                    )
                )
            }
            
            // 进化系统入口
            item {
                EvolutionSystemCard(
                    onEnterEvolution = onNavigateToEvolution,
                    onEnterCombat = onNavigateToCombat
                )
            }
            
            // 硬件防护状态
            item {
                HardwareShieldsCard(
                    camera = state.cameraShield,
                    microphone = state.micShield,
                    screen = state.screenShield,
                    usb = state.usbShield
                )
            }
        }
    }
}

@Composable
fun FusionStatusCard(
    vpnState: VpnState,
    threatLevel: ThreatLevel,
    hardwareProtected: Boolean,
    onConnect: (VpnMode) -> Unit,
    onDisconnect: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(1000), RepeatMode.Reverse)
    )
    
    val statusColor = when {
        threatLevel == ThreatLevel.CRITICAL -> Color(0xFFF44336)
        threatLevel == ThreatLevel.HIGH -> Color(0xFFFF9800)
        vpnState is VpnState.Connected && hardwareProtected -> Color(0xFF4CAF50)
        vpnState is VpnState.Connected -> Color(0xFF2196F3)
        else -> Color.Gray
    }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = statusColor.copy(alpha = 0.15f)
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .background(
                                    brush = Brush.radialGradient(
                                        listOf(statusColor, statusColor.copy(alpha = 0.5f))
                                    ),
                                    shape = RoundedCornerShape(20.dp)
                                )
                                .scale(if (vpnState is VpnState.Connected) pulse else 1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when {
                                    threatLevel.ordinal >= 2 -> Icons.Rounded.Warning
                                    hardwareProtected -> Icons.Rounded.CheckCircle
                                    else -> Icons.Rounded.Shield
                                },
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(16.dp))
                        
                        Column {
                            Text(
                                text = when {
                                    threatLevel == ThreatLevel.CRITICAL -> "紧急威胁"
                                    threatLevel == ThreatLevel.HIGH -> "警告"
                                    vpnState is VpnState.Connected -> "全面防护"
                                    else -> "未连接"
                                },
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (threatLevel) {
                                    ThreatLevel.CRITICAL, ThreatLevel.HIGH -> statusColor
                                    else -> Color.Unspecified
                                }
                            )
                            
                            Text(
                                text = buildString {
                                    if (vpnState is VpnState.Connected) {
                                        append("${vpnState.mode.name} • ")
                                        append("${vpnState.serverLocation} • ")
                                    }
                                    append("防护: ${threatLevel.name}")
                                    if (hardwareProtected) append(" • 硬件锁")
                                },
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                
                if (vpnState is VpnState.Disconnected) {
                    Button(onClick = { onConnect(VpnMode.STANDARD) }) {
                        Text("连接")
                    }
                } else {
                    OutlinedButton(onClick = onDisconnect) {
                        Text("断开")
                    }
                }
            }
        }
    }
}

@Composable
fun ModeSelector(
    currentMode: VpnMode,
    modes: List<ModeConfig>,
    onSelect: (VpnMode) -> Unit
) {
    Column {
        Text(
            "选择模式",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(bottom = 12.dp)
        )
        
        modes.forEach { mode ->
            val isSelected = currentMode == mode.id
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                onClick = { onSelect(mode.id) },
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) mode.color.copy(alpha = 0.15f) 
                        else MaterialTheme.colorScheme.surface
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(mode.color.copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(mode.icon, null, tint = mode.color)
                    }
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    Column(modifier = Modifier.weight(1f)) {
                        Text(mode.name, fontWeight = FontWeight.Medium)
                        Text(mode.desc, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    
                    if (isSelected) {
                        Icon(Icons.Rounded.CheckCircle, null, tint = mode.color)
                    }
                }
            }
        }
    }
}

@Composable
fun UltimateTopBar(state: DashboardState) {
    CenterAlignedTopAppBar(
        title = { Text("NetShield Ultimate") },
        actions = {
            IconButton(onClick = { }) {
                BadgedBox(badge = { if (state.notificationCount > 0) Badge { Text(state.notificationCount.toString()) } }) {
                    Icon(Icons.Rounded.Notifications, null)
                }
            }
            IconButton(onClick = { }) {
                Icon(Icons.Rounded.Settings, null)
            }
        }
    )
}

@Composable
fun UltimateBottomBar(selectedTab: Int, onSelect: (Int) -> Unit) {
    NavigationBar {
        NavigationBarItem(
            icon = { Icon(Icons.Rounded.Shield, null) },
            label = { Text("防护") },
            selected = selectedTab == 0,
            onClick = { onSelect(0) }
        )
        NavigationBarItem(
            icon = { Icon(Icons.Rounded.Speed, null) },
            label = { Text("速度") },
            selected = selectedTab == 1,
            onClick = { onSelect(1) }
        )
        NavigationBarItem(
            icon = { Icon(Icons.Rounded.History, null) },
            label = { Text("日志") },
            selected = selectedTab == 2,
            onClick = { onSelect(2) }
        )
        NavigationBarItem(
            icon = { Icon(Icons.Rounded.Person, null) },
            label = { Text("我的") },
            selected = selectedTab == 3,
            onClick = { onSelect(3) }
        )
    }
}

// Stub composables
@Composable
fun ThreatMapCard(networkThreats: Int, p2pThreats: Int, hardwareAlerts: Int) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("威胁监控", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(networkThreats.toString(), style = MaterialTheme.typography.headlineMedium)
                    Text("网络威胁", fontSize = 12.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(p2pThreats.toString(), style = MaterialTheme.typography.headlineMedium)
                    Text("P2P威胁", fontSize = 12.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(hardwareAlerts.toString(), style = MaterialTheme.typography.headlineMedium)
                    Text("硬件警报", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun SpeedDashboard(vpnSpeed: SpeedInfo, p2pSpeed: SpeedInfo, optimizationLevel: Float) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("网络速度", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("下载: ${vpnSpeed.download} Mbps")
                    Text("上传: ${vpnSpeed.upload} Mbps")
                }
                Text("优化: ${(optimizationLevel * 100).toInt()}%")
            }
        }
    }
}

@Composable
fun QuickActionsGrid(actions: List<QuickAction>) {
    Column {
        Text("快速操作", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 12.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            actions.take(4).forEach { action ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FilledIconButton(onClick = action.onClick) {
                        Icon(action.icon, null)
                    }
                    Text(action.label, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun HardwareShieldsCard(camera: Boolean, microphone: Boolean, screen: Boolean, usb: Boolean) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("硬件防护", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                ShieldItem("摄像头", camera)
                ShieldItem("麦克风", microphone)
                ShieldItem("屏幕", screen)
                ShieldItem("USB", usb)
            }
        }
    }
}

@Composable
fun ShieldItem(name: String, active: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            if (active) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
            null,
            tint = if (active) Color(0xFF4CAF50) else Color.Gray
        )
        Text(name, fontSize = 12.sp)
    }
}

// Data classes
data class ModeConfig(
    val id: VpnMode,
    val name: String,
    val desc: String,
    val icon: ImageVector,
    val color: Color
)

data class QuickAction(
    val name: String,
    val icon: ImageVector,
    val label: String,
    val onClick: () -> Unit
)

data class SpeedInfo(val download: Float, val upload: Float)

// Enums
enum class VpnMode { STANDARD, SECURE_CORE, TOR, P2P, STEALTH }
enum class ThreatLevel { LOW, MEDIUM, HIGH, CRITICAL }
sealed class VpnState {
    object Disconnected : VpnState()
    data class Connected(val mode: VpnMode, val serverLocation: String) : VpnState()
}

// State
data class DashboardState(
    val selectedTab: Int = 0,
    val vpnState: VpnState = VpnState.Disconnected,
    val currentMode: VpnMode = VpnMode.STANDARD,
    val threatLevel: ThreatLevel = ThreatLevel.LOW,
    val hardwareShieldsActive: Boolean = false,
    val networkThreats: Int = 0,
    val p2pThreats: Int = 0,
    val hardwareAlerts: Int = 0,
    val vpnSpeed: SpeedInfo = SpeedInfo(0f, 0f),
    val p2pSpeed: SpeedInfo = SpeedInfo(0f, 0f),
    val aiOptimizationLevel: Float = 0.85f,
    val cameraShield: Boolean = true,
    val micShield: Boolean = true,
    val screenShield: Boolean = true,
    val usbShield: Boolean = true,
    val notificationCount: Int = 0
)

// 进化系统入口卡片
@Composable
fun EvolutionSystemCard(
    onEnterEvolution: () -> Unit,
    onEnterCombat: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "🧬 进化系统",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            
            Text(
                text = "自动学习新技术，实时进化能力",
                fontSize = 12.sp,
                color = Color.Gray,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )
            
            Row(modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = onEnterEvolution,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF4CAF50)
                    )
                ) {
                    Icon(Icons.Rounded.Biotech, null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("技术进化")
                }
                
                Spacer(modifier = Modifier.width(12.dp))
                
                Button(
                    onClick = onEnterCombat,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFF44336)
                    )
                ) {
                    Icon(Icons.Rounded.LocalFireDepartment, null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("战斗模式")
                }
            }
        }
    }
}
