package com.netshield.ultimate.evolution.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.netshield.ultimate.evolution.discovery.NetworkScanner
import com.netshield.ultimate.evolution.discovery.TechScout
import com.netshield.ultimate.evolution.learning.AutoLearner
import com.netshield.ultimate.evolution.deployment.CapabilityIntegrator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class EvolutionViewModel @Inject constructor(
    private val techScout: TechScout,
    private val networkScanner: NetworkScanner,
    private val autoLearner: AutoLearner,
    private val capabilityIntegrator: CapabilityIntegrator
) : ViewModel() {
    
    val techDiscoveries: StateFlow<List<TechScout.DiscoveredTech>> = techScout.discoveredTech
    val networkScan: StateFlow<NetworkScanner.ScanState> = networkScanner.scanResults
    val learningTasks: StateFlow<List<AutoLearner.LearningTask>> = autoLearner.learningTasks
    val integrationQueue: StateFlow<List<CapabilityIntegrator.IntegrationTask>> = capabilityIntegrator.integrationQueue
    
    init {
        // 启动自动侦察
        viewModelScope.launch {
            techScout.startScouting()
        }
        viewModelScope.launch {
            networkScanner.startPeriodicScanning(24)
        }
    }
    
    fun startLearning(tech: TechScout.DiscoveredTech) {
        autoLearner.startLearning(tech)
    }
    
    fun deployIntegration(task: CapabilityIntegrator.IntegrationTask) {
        viewModelScope.launch {
            capabilityIntegrator.executeIntegration(task)
        }
    }
    
    fun startManualScan() {
        viewModelScope.launch {
            networkScanner.performComprehensiveScan()
        }
    }
}
