package com.netshield.ultimate.warroom.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.netshield.ultimate.warroom.combat.CombatExperienceEngine
import com.netshield.ultimate.warroom.combat.CountermeasureForge
import com.netshield.ultimate.warroom.experience.SkillTree

@Composable
fun CombatDashboard(viewModel: CombatViewModel = hiltViewModel()) {
    val activeEngagements by viewModel.activeEngagements.collectAsState()
    val experienceStats by viewModel.experienceStats.collectAsState()
    val skillTree by viewModel.skillTree.collectAsState()
    val forgedWeapons by viewModel.forgedWeapons.collectAsState()
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0F))
            .padding(16.dp)
    ) {
        // 等级与经验条
        CombatLevelHeader(stats = experienceStats)
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // 活跃交战列表
        if (activeEngagements.isNotEmpty()) {
            Text(
                text = "🔥 ACTIVE COMBAT (${activeEngagements.size})",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFF4444)
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(activeEngagements) { engagement ->
                    EngagementCard(engagement = engagement)
                }
                
                // 刚锻造的武器
                if (forgedWeapons.isNotEmpty()) {
                    item {
                        Text(
                            text = "⚔️ FORGED WEAPONS",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFAA00),
                            modifier = Modifier.padding(top = 16.dp)
                        )
                    }
                    
                    items(forgedWeapons) { weapon ->
                        ForgedWeaponCard(weapon = weapon)
                    }
                }
            }
        } else {
            // 和平时期：显示技能树
            SkillTreeView(skillTree = skillTree)
        }
    }
}

@Composable
fun CombatLevelHeader(stats: CombatExperienceEngine.ExperienceStats) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 等级徽章
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                when (stats.combatLevel) {
                                    in 1..10 -> Color(0xFFCD7F32) // 铜
                                    in 11..30 -> Color(0xFFC0C0C0) // 银
                                    in 31..50 -> Color(0xFFFFD700) // 金
                                    else -> Color(0xFF00FFFF) // 钻石
                                },
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${stats.combatLevel}",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stats.title,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                
                Text(
                    text = "XP: ${stats.totalExperience} | " +
                           "Battles: ${stats.totalBattles} | " +
                           "Tech: ${stats.techniquesLearned}",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
                
                // 经验进度条
                LinearProgressIndicator(
                    progress = { calculateLevelProgress(stats) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    color = Color(0xFFFFD700),
                    trackColor = Color(0xFF333344)
                )
            }
        }
    }
}

@Composable
fun EngagementCard(engagement: CombatExperienceEngine.ActiveEngagement) {
    val experienceColor = when {
        engagement.experienceGainRate > 100 -> Color(0xFFFFD700)
        engagement.experienceGainRate > 50 -> Color(0xFF00FF00)
        else -> Color(0xFF888888)
    }
    
    Card(
        colors = CardDefaults.cardColors(
            containerColor = when (engagement.status) {
                CombatExperienceEngine.EngagementStatus.COUNTER_ATTACKING -> Color(0xFF2A1A1A)
                CombatExperienceEngine.EngagementStatus.EVOLVED -> Color(0xFF1A2A1A)
                else -> Color(0xFF1A1A2E)
            }
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(
                            color = when {
                                engagement.attackerProfile.sophisticationLevel > 0.9 -> Color.Red
                                engagement.attackerProfile.sophisticationLevel > 0.7 -> Color(0xFFFF6600)
                                engagement.attackerProfile.sophisticationLevel > 0.5 -> Color.Yellow
                                else -> Color.Gray
                            },
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${(engagement.attackerProfile.sophisticationLevel * 100).toInt()}",
                        fontSize = 12.sp,
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Spacer(modifier = Modifier.width(12.dp))
                
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = engagement.attackerProfile.signature.take(8),
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "${engagement.attackVector.type.name} | " +
                               "Round ${engagement.attackerProfile.previousEncounters + 1}",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Star,
                        contentDescription = null,
                        tint = experienceColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "+${engagement.experienceGainRate.toInt()}/s",
                        fontSize = 12.sp,
                        color = experienceColor
                    )
                }
            }
        }
    }
}

@Composable
fun ForgedWeaponCard(weapon: CountermeasureForge.ForgedCountermeasure) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2A2A3E))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Rounded.Shield,
                contentDescription = null,
                tint = Color(0xFFFFAA00),
                modifier = Modifier.size(24.dp)
            )
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = weapon.name,
                    fontWeight = FontWeight.Medium,
                    color = Color.White,
                    fontSize = 14.sp
                )
                Text(
                    text = "Quality: ${(weapon.qualityScore * 100).toInt()}%",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }
            
            Button(
                onClick = { },
                modifier = Modifier.height(32.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFFAA00)
                )
            ) {
                Text("DEPLOY", fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun SkillTreeView(skillTree: SkillTree.SkillTreeDefinition) {
    Column {
        Text(
            text = "🌳 SKILL TREE",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF4CAF50)
        )
        
        Spacer(modifier = Modifier.height(12.dp))
        
        skillTree.branches.forEach { branch ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = branch.name,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = branch.description,
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    branch.nodes.forEach { node ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = if (node.currentLevel > 0) 
                                    Icons.Rounded.CheckCircle else Icons.Rounded.Circle,
                                contentDescription = null,
                                tint = if (node.currentLevel > 0) Color(0xFF4CAF50) else Color.Gray,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "${node.name} (${node.currentLevel}/${node.maxLevel})",
                                fontSize = 12.sp,
                                color = if (node.currentLevel > 0) Color.White else Color.Gray
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun calculateLevelProgress(stats: CombatExperienceEngine.ExperienceStats): Float {
    val xpForNextLevel = stats.combatLevel * 1000
    val currentLevelXp = (stats.combatLevel - 1) * 1000
    val xpInCurrentLevel = stats.totalExperience - currentLevelXp
    return (xpInCurrentLevel.toFloat() / xpForNextLevel.toFloat()).coerceIn(0f, 1f)
}
